export const url: string = import.meta.env.VITE_API_URL as string;
