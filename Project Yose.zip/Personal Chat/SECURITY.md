# Security Policy

## Reporting a Vulnerability

Please report a vulnerability to security@tinode.co

Please do not report Firebase initialization tokens. The Firebase tokens are really public: they must be included into client applications and consequently are not private by design.
