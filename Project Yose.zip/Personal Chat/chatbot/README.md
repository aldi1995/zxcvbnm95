# Tinode ChatBot Examples

* [Python chatbot](python/)
* [C# .Net/.NetCore chatbot](https://github.com/tinode/csharpbot)
