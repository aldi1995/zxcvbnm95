# Tinode Chatbot Example for .Net or .NetCore

Moved to a separate repo: https://github.com/tinode/csharpbot
